'''Create a random vector of size 30 and find the mean value
'''
import numpy as np
x=np.random.random(30)
print("Vector is           : ",x)

print("Mean from Vector is : ",x.mean())
